#!/usr/bin/env python

import numpy as np


def read_graph(file_name):
    with open(file_name, 'r') as f:
        graph_f = f.readlines()  # content[1] contains the num nodes. content[4] and beyond contains vertices
        num_nodes = int(graph_f[1])
        matrix = np.zeros(shape=(num_nodes, num_nodes))  # create empty numpy matrix (num_nodes x num_nodes)

        for i in range(4, len(graph_f)):  # fill the matrix
            matr_x = int(graph_f[i][0])
            matr_y = int(graph_f[i][5])
            matrix[matr_x][matr_y] = 1
            matrix[matr_y][matr_x] = 1

        for i in range(0, len(matrix)):
            print matrix[i]

        return np.matrix(matrix)


def find_path(matrix, m):
    power_matrix = matrix ** m
    for x in range(0, len(matrix)):
        for y in range(0, x + 1):
            if matrix[x, y] == 1:
                print "From " + str(x) + " to " + str(y) + ": " + str(power_matrix[x, y])


def main():
    find_path(read_graph("graph"), 4)


if __name__ == "__main__":
    main()
