package Models;

public class UserRating extends Rating {
    UserRating(int id, float rating) {
        super(id, rating);
    }
}
